$(document).ready(function(){
$("#sideMenu").hide();});
$(document).ready(function(){
  $("#lines").click(function(){
    $("#sideMenu").slideToggle(300);
  });
});